# tradier

Python wrapper for the tradier brokerage API

Class based functionality currently in development. Code is found in tradier.py


To get tradier.py to work, need to have 'tradier_acct' and 'tradier_token' defined in a .env file in the same directory.

From a python file / jupyter notebook, just run `from tradier import *`
