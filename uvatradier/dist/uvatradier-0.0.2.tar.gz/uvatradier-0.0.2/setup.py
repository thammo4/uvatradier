from setuptools import setup, find_packages

setup(
	name='uvatradier',
	version='0.0.2',
	packages=find_packages(),
	author='tom hammons',
	description='wahoowah'
)
